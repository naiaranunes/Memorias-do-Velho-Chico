<?php
    $dbHost = 'Localhost';
    $dbUsername = 'root';
    $dbPassword= '';
    $dbName = 'memorias_velho_chico';

    $conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

?>


